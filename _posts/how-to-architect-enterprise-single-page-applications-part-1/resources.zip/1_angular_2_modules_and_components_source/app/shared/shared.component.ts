import {Component} from '@angular/core';

@Component({
  selector: 'shared-component',
  template: `<div>I am the shared component</div>`
})
export class SharedComponent{}
