import { NgModule }      from '@angular/core';
import { SharedComponent } from './shared.component'

@NgModule({
  imports: [  ],
  declarations: [ SharedComponent ],
  exports: [ SharedComponent ]
})
export class SharedModule {}
