import { NgModule }      from '@angular/core';
import { GrandChildComponent } from './grand-child.component'

import { SharedModule } from '../shared/shared.module'

@NgModule({
  imports: [ SharedModule  ],
  declarations: [ GrandChildComponent ],
  exports: [ GrandChildComponent ]
})
export class GrandChildModule {}
