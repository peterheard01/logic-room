import {Component} from '@angular/core';

@Component({
  selector: 'grand-child-component',
  template: `<div>I am the grand child component</div>
             <shared-component></shared-component>`
})
export class GrandChildComponent{}
