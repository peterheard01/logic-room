import {Component} from '@angular/core';

@Component({
  selector: 'my-app',
  template: `<div>{{title}}</div>
            <child-component></child-component>`,
})
export class AppComponent {
  title = 'I am the app component';
}






