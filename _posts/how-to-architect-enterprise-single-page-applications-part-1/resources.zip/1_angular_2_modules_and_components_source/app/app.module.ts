import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent }  from './app.component';

import { ChildModule}  from './child/child.module';

@NgModule({
  imports: [ BrowserModule,ChildModule ],
  declarations: [ AppComponent ],
  bootstrap: [ AppComponent ]
})
export class AppModule {
  constructor(){
    console.log('I am the app module');
  }
}


