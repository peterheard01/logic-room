import { NgModule }      from '@angular/core';
import { ChildComponent } from './child.component'

import { GrandChildModule } from '../grand-child/grand-child.module'

import { SharedModule } from '../shared/shared.module'

@NgModule({
  imports: [ GrandChildModule, SharedModule ],
  declarations: [ ChildComponent],
  exports: [ ChildComponent ]
})
export class ChildModule {}
