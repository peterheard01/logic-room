import {Component} from '@angular/core';

@Component({
  selector: 'child-component',
  template: `<div>I am the child component</div>
            <shared-component></shared-component>
            <grand-child-component></grand-child-component>`
})
export class ChildComponent{}
